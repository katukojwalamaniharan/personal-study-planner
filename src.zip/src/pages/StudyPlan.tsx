import { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Heading,
  Button,
  useColorModeValue,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  ModalCloseButton,
  Input,
  useDisclosure,
  useToast,
  FormControl,
  FormLabel,
  NumberInput,
  NumberInputField,
  NumberInputStepper,
  NumberIncrementStepper,
  NumberDecrementStepper,
  Progress,
  Text,
  VStack,
  HStack,
  Badge,
  Alert,
  AlertIcon,
  AlertTitle,
  AlertDescription,
  Select,
  Icon
} from '@chakra-ui/react';
import { FaPlus, FaFlag } from 'react-icons/fa';
import Sidebar from '../components/Sidebar';
import { useAuth } from '../contexts/AuthContext';
import { 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  where, 
  serverTimestamp,
  onSnapshot,
  deleteDoc,
  doc,
  updateDoc,
  orderBy
} from 'firebase/firestore';
import { db } from '../config/firebase';

// Define the Course type
type Course = {
  id: string;
  name: string;
  duration: number; // in weeks
  progress: number; // percentage
  priority: 'high' | 'medium' | 'low';
  createdAt: any;
  userId: string;
};

const StudyPlan = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [newCourse, setNewCourse] = useState('');
  const [duration, setDuration] = useState(12); // default 12 weeks
  const [progress, setProgress] = useState(0);
  const [priority, setPriority] = useState<'high' | 'medium' | 'low'>('medium');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const toast = useToast();
  const { currentUser } = useAuth();

  // Fetch courses when component mounts
  useEffect(() => {
    if (!currentUser) {
      console.log('No user logged in');
      return;
    }

    console.log('Setting up courses listener for user:', currentUser.uid);
    const q = query(
      collection(db, 'user_study_plans', currentUser.uid, 'courses'),
      orderBy('priority', 'desc'),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, 
      (snapshot) => {
        console.log('Received courses update');
        const coursesData = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as Course[];
        console.log('Courses data:', coursesData);
        setCourses(coursesData);
        setError(null);
      },
      (error) => {
        console.error('Error fetching courses:', error);
        setError('Failed to load courses. Please try again.');
      }
    );

    return () => {
      console.log('Cleaning up courses listener');
      unsubscribe();
    };
  }, [currentUser]);

  const handleAddCourse = async () => {
    if (!currentUser) {
      setError('You must be logged in to add a course');
      return;
    }

    if (!newCourse.trim()) {
      setError('Please enter a course name');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      console.log('Adding new course:', {
        name: newCourse.trim(),
        duration,
        progress,
        priority,
        userId: currentUser.uid
      });

      const courseData = {
        name: newCourse.trim(),
        duration,
        progress,
        priority,
        userId: currentUser.uid,
        createdAt: serverTimestamp()
      };

      const docRef = await addDoc(
        collection(db, 'user_study_plans', currentUser.uid, 'courses'),
        courseData
      );

      console.log('Course added successfully with ID:', docRef.id);

      toast({
        title: 'Success',
        description: 'Course added successfully',
        status: 'success',
        duration: 3000,
        isClosable: true,
      });

      setNewCourse('');
      setDuration(12);
      setProgress(0);
      setPriority('medium');
      onClose();
    } catch (error: any) {
      console.error('Error adding course:', error);
      setError(error.message || 'Failed to add course');
      toast({
        title: 'Error',
        description: error.message || 'Failed to add course',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateProgress = async (courseId: string, newProgress: number) => {
    if (!currentUser) return;

    try {
      console.log('Updating course progress:', { courseId, newProgress });
      const courseRef = doc(db, 'user_study_plans', currentUser.uid, 'courses', courseId);
      await updateDoc(courseRef, {
        progress: newProgress,
        updatedAt: serverTimestamp()
      });
      console.log('Progress updated successfully');
    } catch (error: any) {
      console.error('Error updating progress:', error);
      setError(error.message || 'Failed to update progress');
      toast({
        title: 'Error',
        description: error.message || 'Failed to update progress',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };

  const handleUpdatePriority = async (courseId: string, newPriority: 'high' | 'medium' | 'low') => {
    if (!currentUser) return;

    try {
      console.log('Updating course priority:', { courseId, newPriority });
      const courseRef = doc(db, 'user_study_plans', currentUser.uid, 'courses', courseId);
      await updateDoc(courseRef, {
        priority: newPriority,
        updatedAt: serverTimestamp()
      });
      console.log('Priority updated successfully');
    } catch (error: any) {
      console.error('Error updating priority:', error);
      setError(error.message || 'Failed to update priority');
      toast({
        title: 'Error',
        description: error.message || 'Failed to update priority',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };

  const handleDeleteCourse = async (courseId: string) => {
    if (!currentUser) return;

    try {
      console.log('Deleting course:', courseId);
      const courseRef = doc(db, 'user_study_plans', currentUser.uid, 'courses', courseId);
      await deleteDoc(courseRef);
      console.log('Course deleted successfully');
      toast({
        title: 'Success',
        description: 'Course deleted successfully',
        status: 'success',
        duration: 3000,
        isClosable: true,
      });
    } catch (error: any) {
      console.error('Error deleting course:', error);
      setError(error.message || 'Failed to delete course');
      toast({
        title: 'Error',
        description: error.message || 'Failed to delete course',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };

  const getPriorityColor = (priority: 'high' | 'medium' | 'low') => {
    switch (priority) {
      case 'high':
        return 'red';
      case 'medium':
        return 'orange';
      case 'low':
        return 'green';
      default:
        return 'gray';
    }
  };

  return (
    <Box minH="100vh" bg={useColorModeValue('gray.50', 'gray.900')}>
      <Sidebar />
      <Box ml="280px" p={8}>
        <Container maxW="container.xl">
          <Heading size="lg" mb={6}>
            Study Plan
          </Heading>

          {error && (
            <Alert status="error" mb={4}>
              <AlertIcon />
              <AlertTitle>Error!</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <Button 
            leftIcon={<FaPlus />} 
            colorScheme="blue" 
            onClick={onOpen}
            isLoading={isLoading}
          >
            Add Course
          </Button>

          {/* Display Courses */}
          <VStack spacing={4} mt={8} align="stretch">
            {courses.map((course) => (
              <Box
                key={course.id}
                p={6}
                bg={useColorModeValue('white', 'gray.800')}
                borderRadius="lg"
                shadow="base"
                borderLeft="4px solid"
                borderLeftColor={getPriorityColor(course.priority)}
              >
                <VStack align="stretch" spacing={4}>
                  <HStack justify="space-between">
                    <HStack>
                      <Text fontSize="xl" fontWeight="bold">{course.name}</Text>
                      <Badge colorScheme={getPriorityColor(course.priority)}>
                        <Icon as={FaFlag} mr={1} />
                        {course.priority}
                      </Badge>
                    </HStack>
                    <Badge colorScheme={course.progress === 100 ? 'green' : 'blue'}>
                      {course.progress}%
                    </Badge>
                  </HStack>
                  <Text color="gray.500">Duration: {course.duration} weeks</Text>
                  <Progress value={course.progress} colorScheme="blue" size="lg" borderRadius="full" />
                  <HStack justify="space-between">
                    <HStack>
                      <Button 
                        size="sm" 
                        onClick={() => handleUpdateProgress(course.id, Math.max(0, course.progress - 10))}
                        isDisabled={course.progress <= 0}
                      >
                        -10%
                      </Button>
                      <Button 
                        size="sm" 
                        onClick={() => handleUpdateProgress(course.id, Math.min(100, course.progress + 10))}
                        isDisabled={course.progress >= 100}
                      >
                        +10%
                      </Button>
                      <Select
                        size="sm"
                        value={course.priority}
                        onChange={(e) => handleUpdatePriority(course.id, e.target.value as 'high' | 'medium' | 'low')}
                        width="100px"
                      >
                        <option value="high">High</option>
                        <option value="medium">Medium</option>
                        <option value="low">Low</option>
                      </Select>
                    </HStack>
                    <Button 
                      size="sm" 
                      colorScheme="red" 
                      variant="ghost"
                      onClick={() => handleDeleteCourse(course.id)}
                    >
                      Delete
                    </Button>
                  </HStack>
                </VStack>
              </Box>
            ))}
          </VStack>
        </Container>
      </Box>

      {/* Add Course Modal */}
      <Modal isOpen={isOpen} onClose={onClose} isCentered>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Add New Course</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <VStack spacing={4}>
              <FormControl isRequired>
                <FormLabel>Course Name</FormLabel>
                <Input
                  placeholder="Enter course name"
                  value={newCourse}
                  onChange={(e) => setNewCourse(e.target.value)}
                  autoFocus
                />
              </FormControl>

              <FormControl isRequired>
                <FormLabel>Duration (weeks)</FormLabel>
                <NumberInput
                  min={1}
                  max={52}
                  value={duration}
                  onChange={(_, value) => setDuration(value)}
                >
                  <NumberInputField />
                  <NumberInputStepper>
                    <NumberIncrementStepper />
                    <NumberDecrementStepper />
                  </NumberInputStepper>
                </NumberInput>
              </FormControl>

              <FormControl isRequired>
                <FormLabel>Priority</FormLabel>
                <Select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as 'high' | 'medium' | 'low')}
                >
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </Select>
              </FormControl>

              <FormControl isRequired>
                <FormLabel>Initial Progress (%)</FormLabel>
                <NumberInput
                  min={0}
                  max={100}
                  value={progress}
                  onChange={(_, value) => setProgress(value)}
                >
                  <NumberInputField />
                  <NumberInputStepper>
                    <NumberIncrementStepper />
                    <NumberDecrementStepper />
                  </NumberInputStepper>
                </NumberInput>
              </FormControl>
            </VStack>
          </ModalBody>
          <ModalFooter>
            <Button 
              colorScheme="blue" 
              mr={3} 
              onClick={handleAddCourse}
              isLoading={isLoading}
            >
              Add
            </Button>
            <Button 
              variant="ghost" 
              onClick={onClose}
              isDisabled={isLoading}
            >
              Cancel
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Box>
  );
};

export default StudyPlan; 